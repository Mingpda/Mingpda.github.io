import numpy as np
from os import listdir
from os.path import isfile, join
import cv2
import pygame
import time
import sys
from pygame.locals import *
from Recognition import Recognition
import random
import finger
import webbrowser

music_note_dumb = [22,100,185,260,335,410,485,560,635,710,785,860,935,1010,1085,1160,1235]
music_note_galaxy = [115,185,250,315,370,435,500,565,630,695,760,825,890,955,1020,1080,1140,1200,1250,1310,1370,1430,1490,1550]

def randIdx():
    x = random.randrange(100,500)
    y = random.randrange(100,300)
    return (x,y)

def randPos():
    return random.randrange(0,4)

def randColor():
    x = random.randrange(0,255)
    y = random.randrange(0,255)
    z = random.randrange(0,255)
    return (x,y,z)

def meanPos(P1, P2):
    x = P1[0]+P2[0]
    y = P1[1]+P2[1]
    return (int(x/2), int(y/2))

def writeInfo(userList):
    f = open("Userinfo.txt",'w')
    for i in range(0,2):
        for j in range(0,3):
            data = "name:"+str(userList[i][j].name)+",score:"+str(userList[i][j].score)+"\n"
            f.write(data)
    f.close()

class UserInfo:
    def __init__(self, name, score):
        self.name = name
        self.score = score

def face_detect():
    string = "Show your face to login.."
    Recognition.camera_on(string, capture)
    capture.release()
    cv2.destroyAllWindows()

def fingerToStart():
    capture = cv2.VideoCapture(0)
    finger.mainex((200,200), (400,400))

    capture.release()
    cv2.destroyAllWindows()

def selectMusic():
    selected = False
    capture = cv2.VideoCapture(0)
    while True:
        ret, img = capture.read()
        img = cv2.flip(img,1)
        cv2.putText(img, "Select Music", (200, 50), cv2.FONT_HERSHEY_COMPLEX , 1, (0, 0, 0),2)
        img = cv2.rectangle(img,(100,100), (300,300), (0,255,0), 2)
        cv2.putText(img, "Dumb Dumb", (75, 300), cv2.FONT_HERSHEY_COMPLEX , 1, (255, 0, 255),1)
        img = cv2.rectangle(img,(400,100), (600,300), (0,255,0), 2)
        cv2.putText(img, "Galaxy", (400, 300), cv2.FONT_HERSHEY_COMPLEX , 1, (255, 0, 255),1)
        if finger.process(img, False, (100,100), (200,200)):
            music_note = music_note_dumb
            music_file="dumb.mp3"
            selected = True
            
        if finger.process(img, False, (400,100), (600,300)):
            music_note = music_note_galaxy
            music_file="galaxy.mp3"
            selected = True

        if selected :
            capture.release()
            cv2.destroyAllWindows()
            return music_file
        cv2.imshow("select",img)
        if cv2.waitKey(1) > 0:
            break
        
     

def playMusic():
    pygame.init() # 초기화
    music_file = selectMusic()
    pygame.mixer.init()
    pygame.mixer.music.load(music_file)
    pygame.mixer.music.play()
    if music_file=="dumb.mp3" :
        return (music_file,music_note_dumb)
    elif music_file=="galaxy.mp3" :
        return (music_file,music_note_galaxy)
    
def mainGame():
    clk = 0;
    score_game = 10;
    idx = 0;
    capture = cv2.VideoCapture(0)
    (music_file,music_note) = playMusic()
    clock = pygame.time.Clock()
    while True:
        ret, img = capture.read()
        img = cv2.flip(img,1)
        cv2.putText(img, "score :"+str(score_game), (50, 400), cv2.FONT_HERSHEY_COMPLEX , 1, (255, 0, 255),2)
        if clk < 12 :
            cv2.putText(img, "Ready", (300, 240), cv2.FONT_HERSHEY_COMPLEX , 1, (255, 0, 255),2)
        elif clk<22:
            cv2.putText(img, "Go", (300, 240), cv2.FONT_HERSHEY_COMPLEX , 1, (255, 0, 255),2)
        else :
            if clk == music_note[idx] :
                (x,y) = randIdx()
                (b,g,r) = randColor()
                pos = randPos()
            if clk<music_note[idx]+22 and clk>music_note[idx]:
                mv = clk-music_note[idx]
                mv *= 4
                if pos == 0:
                    X = (x+mv,y+mv)
                    Y = (x+150+mv, y+150+mv)
                elif pos==1:
                    X = (x-mv,y-mv)
                    Y = (x+150-mv, y+150-mv)
                elif pos==2:
                    X = (x+mv,y-mv)
                    Y = (x+150+mv, y+150-mv)
                else:
                    X = (x-mv,y+mv)
                    Y = (x+150-mv, y+150+mv)
                img = cv2.rectangle(img,X, Y, (b+2*mv,g+2*mv,r+2*mv), 2)
                #img = cv2.circle(img, meanPos(X,Y), 80, (0,255,0), 3)
                if finger.process(img, False, X, Y):
                    img = cv2.rectangle(img,X, Y, (b+2*mv,g+2*mv,r+2*mv), -1)
                    #img = cv2.circle(img, meanPos(X,Y), 80, (0,255,0), -1)
                    score_game+=75-(clk-music_note[idx])
                if clk==music_note[idx]+21 :
                    idx+=1
        clock.tick(30)
        cv2.imshow("VideoFrame", img)
        if cv2.waitKey(1) > 0 or idx==len(music_note) :
            pygame.mixer.quit()
            break
        clk+=1   
    capture.release()
    cv2.destroyAllWindows()
    return (score_game,music_file)

def rankManage():
    clk = 0
    (score_game,music_file) = mainGame()

    Recognition.insertScore(score_game, music_file)
    userList = Recognition.returnUserList()
                
    ranking = np.zeros((480,640,3), dtype=np.uint8)
    cv2.putText(ranking, "Ranking - ", (160, 50), cv2.FONT_HERSHEY_COMPLEX , 1, (255, 255, 255),2)
    cv2.putText(ranking, "Press Enter to Continue...", (100, 350), cv2.FONT_HERSHEY_COMPLEX , 1, (255, 255, 255),2)
    i = 1;
    if music_file=="dumb.mp3" :
        music_idx=0
    else:
        music_idx=1
    music_file=music_file[:-4]
    for user in userList[music_idx][0:3]:
        cv2.putText(ranking, music_file, (360,50), cv2.FONT_HERSHEY_COMPLEX , 1, (255, 255, 255),2)
        image_user = cv2.imread('C:\\Users\\user\\Image_Process\\faces\\'+str(user.name)+'.png', cv2.IMREAD_GRAYSCALE)
        cv2.putText(ranking, str(user.name)+": "+str(user.score), (50, 100+50*i), cv2.FONT_HERSHEY_COMPLEX , 1, (255, 255, 255),1)
        i+=1
        
    writeInfo(userList)
    webbrowser.open("aa.html")
    cv2.imshow("rank",ranking)
    if cv2.waitKey(1) > 0:
        return


def mainGameManage():
    face_detect()
    fingerToStart()
    rankManage()
    if cv2.waitKey(0) == 13:
        return False
    capture = cv2.VideoCapture(0)
    capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    return True


userList = [UserInfo(0,0),UserInfo(0,0),UserInfo(0,0)]

while True:
    capture = cv2.VideoCapture(0)
    capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    if mainGameManage():
        break;
    capture.release()
    cv2.destroyAllWindows()
    time.sleep(1)

if cv2.waitKey(1) > 0:
    capture.release()
    cv2.destroyAllWindows()
