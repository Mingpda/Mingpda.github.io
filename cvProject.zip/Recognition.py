import cv2
import numpy as np
from os import listdir
from os.path import isfile, join
import tkinter as tk
face_classifier = cv2.CascadeClassifier("C:\\Users\\user\\Image_Process\\haarcascade_frontface.xml")

class UserInfo:
    def __init__(self, name, score):
        self.name = name
        self.score = score

userList = [[UserInfo(0,0),UserInfo(0,0),UserInfo(0,0),UserInfo(0,0)],
            [UserInfo(0,0),UserInfo(0,0),UserInfo(0,0),UserInfo(0,0)]]
        
class Recognition:
    count = 0

    def InputData():
        # 웹캠에서 영상을 읽어온다
        cap = cv2.VideoCapture(0)
        cap.set(3, 640)  # WIDTH
        cap.set(4, 480)  # HEIGHT
        face_cascade = cv2.CascadeClassifier()
        # 얼굴 인식 캐스케이드 파일 읽는다
        face_cascade.load("C:\\Users\\user\\Image_Process\\haarcascade_frontface.xml")

        while (True):
            # frame 별로 capture 한다
            ret, frame = cap.read()

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)

            # 인식된 얼굴 갯수를 출력
            #print(len(faces))

            # 인식된 얼굴에 사각형을 출력한다
            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

            # 화면에 출력한다
            cv2.imshow('frame', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()


        # 전체 사진에서 얼굴 부위만 잘라 리턴
    def face_extractor(img):
        # 흑백처리
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # 얼굴 찾기
        faces = face_classifier.detectMultiScale(gray, 1.3, 5)
        # 찾은 얼굴이 없으면 None으로 리턴
        if faces is ():
            return None
        # 얼굴들이 있으면
        for (x, y, w, h) in faces:
            # 해당 얼굴 크기만큼 cropped_face에 잘라 넣기
            # 근데... 얼굴이 2개 이상 감지되면??
            # 가장 마지막의 얼굴만 남을 듯
            cropped_face = img[y:y + h, x:x + w]
        # cropped_face 리턴
        return cropped_face

    def insertScore(score, music):
        userList[0][3].score = score
        if music=="galaxy.mp3" :
            userList[1][3].score = userList[0][3].score
            userList[1][3].name = userList[0][3].name
            music_idx = 1
        else :
            music_idx = 0
            
        for i in range(0,4):
            for j in range(i+1,4):
                if int(userList[music_idx][i].score)<int(userList[music_idx][j].score) :
                    temp = userList[music_idx][i].score
                    userList[music_idx][i].score = userList[music_idx][j].score
                    userList[music_idx][j].score = temp
                    
                    temp = userList[music_idx][i].name
                    userList[music_idx][i].name = userList[music_idx][j].name
                    userList[music_idx][j].name = temp

    def returnUserList():
            return userList


    def camera_on(str_img, cap):
        def insertList(nm):
            userList[0][3].name=nm
        
        # 카메라 실행
        #cap = cv2.VideoCapture(0)
        # 저장할 이미지 카운트 변수
        count = 0
        while True:
            # 카메라로 부터 사진 1장 얻기
            ret, frame = cap.read()
            cv2.putText(frame, str_img, (60, 50), cv2.FONT_ITALIC, 1, (0, 0, 0),3)
            cv2.imshow("VideoFrame", frame)
            # 얼굴 감지 하여 얼굴만 가져오기
            if Recognition.face_extractor(frame) is not None :
                count += 1
                # 얼굴 이미지 크기를 200x200으로 조정
                face = cv2.resize(Recognition.face_extractor(frame), (200, 200))
                # 조정된 이미지를 흑백으로 변환
                face = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
                # faces폴더에 jpg파일로 저장
                # ex > faces/user0.jpg   faces/user1.jpg ....
                file_name_path = 'C:\\Users\\user\\Image_Process\\faces\\user.png'
                cv2.imwrite(file_name_path, face)

                root = tk.Tk()
                root.title("user info")
                root.geometry("300x300")

                def func(event):
                    name = tk.Entry.get(entry)
                    cv2.imwrite('C:\\Users\\user\\Image_Process\\faces\\'+name+'.png', face)
                    if insertList(name):
                        return;
                
                image = tk.PhotoImage(file="C:\\Users\\user\\Image_Process\\faces\\user.png")
                label = tk.Label(root, image=image)
                label.pack()
                entry = tk.Entry(root, width=30)
                entry.pack()
                root.bind('<Return>', func)
                root.mainloop()

                # 화면에 얼굴과 현재 저장 개수 표시
                cv2.putText(face, str(count), (50, 50), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 2)
                cv2.imshow('Face Cropper', face)
                break 
            else:
                #print("Face not Found")
                pass

            if cv2.waitKey(1) == 13:
                break

        cap.release()
        cv2.destroyAllWindows()
        print('Colleting Samples Complete!!!')


    
